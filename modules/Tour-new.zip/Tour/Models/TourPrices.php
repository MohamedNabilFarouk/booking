<?php

namespace Modules\Tour\Models;

use Illuminate\Database\Eloquent\Model;

class TourPrices extends Model
{
    //
    protected $table  = 'tour_prices';

    protected $fillable=[
        'tour_id',
        'ip',
        'price',
    ];

    public function tour(){
        return $this->belongsTo(Tour::class , 'tour_id', 'id');
    }

  
}
